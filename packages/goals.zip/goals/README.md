# goals, parked

The goals tools, as they stood when they were parked (epic `epic-workflow` P6, Owen 2026-10-11).
- Goals was an early draft:  a plan per project, by topic, that Owen talks through with Claude.
- It will be redone on top of the epic tools:  epic `epic-goals` (a future epic, `epics/epic-goals/`).
- What it was for, and what worked:  the goals guide, `guides/goals/goals.html` (shared).
- This folder lives only inside `packages/goals.zip`:  nothing builds, lints or tests it while it's parked.

## What's here

Every file sits at the path it came from, under this folder:

| Here | Came from | What it is |
| --- | --- | --- |
| `packages/docs/tools/goals/` | the same path | the goals tool (`goals.js`), its page writer, launcher, targets, the page server's goals routes (`goalsRoutes.ts`), their tests, and the five skills under `skills/` |
| `.claude/skills/goals*` | the same path | links into `skills/` above:  `/goals`, `/goals-open`, `/goals-open-vs`, `/goals-thought`, `/goals-update` |
| `packages/cli/src/commands/goalsCommand.ts` | the same path | `spell dev goals`:  finds the goals folder and runs `goals.js` in a child `node` |
| `templates/goals/` | the shared `templates/goals/` | the goals pages' templates (`goals new-set`, `goals new`);  the shared copy stayed in place when parked |
| `unwire.patch` | `git diff` at parking time | every edit that took goals OUT of the repo:  the CLI wiring, `package.json`, the docs configs, the pages' buttons |

What stayed in the repo, because the goals PAGES stayed (Owen:  "left as they are"):
- the pages themselves, the shared `goals/` folder (`goals/<set>/...`), and its link in the root `package.json`
- their look and script:  `packages/docs/tools/_assets/goals.css` and `goals-live.js`
  - `goals-live.js`'s buttons now say "TODO:  this will ..." (`parked()`), instead of calling the routes
- `GOALS` in `packages/docs/tools/pages.js`, and the docs index's Goals card
- `spell dev goals`, as a stub that says goals is parked

## Putting it back

From the repo root, on a branch:

```sh
unzip packages/goals.zip -d packages/            # makes packages/goals/
cp -R packages/goals/packages/docs/tools/goals packages/docs/tools/goals
cp packages/goals/packages/cli/src/commands/goalsCommand.ts packages/cli/src/commands/
cp -P packages/goals/.claude/skills/goals* .claude/skills/        # -P:  copy the links, not their targets
git apply -R packages/goals/unwire.patch         # undo the unwiring:  CLI, package.json, configs, buttons
rm -r packages/goals
```

- `git apply -R` may refuse where the files changed since 2026-10-11:  `git apply -R --3way`, or redo those edits by hand.
  The patch is small and each hunk says what it undoes.
- The templates:  copy `templates/goals/` back into the shared `templates/` only if it was removed there meanwhile.
- Then `yarn install`, `yarn goals:test` (the goals tests run under `node --test`), and `spell dev commands check`.
- Expect bitrot:  the tools lean on `spell dev` and the plan-doc tools of their day, which the epic work keeps changing.
